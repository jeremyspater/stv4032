rm(list=ls())

s = function(x){summary(factor(x))}

set.seed(1985)

#789 farms at 3 times in 2 countries
Country = c(rep('Sweden', 789*3), rep('Norway', 789*3))

#3 times, 500 firms, 2 countries
Time =    rep(
  c(rep(-1, 789), rep(0, 789), rep(1,789)),
  2)

#Treatment is 1 for region A, time 1; 0 otherwise
X = Time == 1 & Country == 'Sweden'

GHG = 
  #Region fixed effects
  1.2*(Country=='Sweden') + 
  1.5*(Country == 'Norway') +
  #Time trend
  -0.1*Time +
  #Treatment effect
  -0.35*X +
  #Individual error term
  abs( #just want positive values
  rnorm(length(Country),
        mean = 1,
        sd = 1)
  )

A = data.frame(Country,
               Time,
               GHG)

#save
#saveRDS(A, 'STV4032Week3ExamP2Input.RDS')
rm(list=ls())
df = readRDS('STV4032Week3ExamP2Input.RDS')

df$Sweden = df$Country == 'Sweden'

#now do a classic 2x2 DiD with two-way fixed effects
df2 = df[df$Time >= 0,]

DiD = lm(
  'GHG ~ Country + Time + Country*Time',
  data = df2
)

summary(DiD)

#Now let's test parallel trends.
df3 = df[df$Time < 1,]

ParTr = lm(
  'GHG ~ Country + Time + Country*Time',
  data = df3
)

summary(ParTr)
