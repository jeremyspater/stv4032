#based on https://github.com/liserodland/stv4020aR/blob/master/H20-seminarer/Fordypningsseminarer/docs/Fordypningsseminar-1-Paneldata.md
#Not doing it, because I don't have the proper data file . . .

library(haven) #for reading .dta data files
library(tidyverse)
library(stargazer)
library(plm) #for working with panel data

data <- read_dta("/Users/jeremyspater/Dropbox/duke/oslo/teaching/4032 spring 2023/seminar exam/part 3 4 may 23/seminar 3 code/v0_neumayer_spess_2005.dta")

data.plm <- pdata.frame(data, index = c("country", "year"))

# X country: land
# X year: år
# X fdi_inflow: hvor mye investeringer et land får
# ? bits: hvor mange investeringsavtaler et land har
# X ln_gdp_pr_cap: logaritmen til BNP per cap
# X ln_population: logaritmen til populasjonen
# X economic_growth: økonomisk vekst
# X inflation: inflasjon
# ? resource_rent: ressursrente (her brukt som mål på hvor mye naturressurser et land har)
# ? bilateral_trade_agreements: antall bilaterale handelsavtaler et land har
# ? wto_member: om et land er medlem i WTO (verdens handelsorganisasjon)
# X polcon3: et mål på troverdigheten til politiske institusjoner når de forplikter seg til politiske tiltak

class(data.plm)
