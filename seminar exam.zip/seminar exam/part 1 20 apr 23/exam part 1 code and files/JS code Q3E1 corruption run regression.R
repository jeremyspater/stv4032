library(tidyverse)
rm(list=ls())

d = read.csv('/Users/jeremyspater/Dropbox/duke/oslo/teaching/4032 spring 2023/seminar exam/part 1 20 apr 23/exam part 1 code and files/4032_2023_week1_Q3_Corruption.csv')

summary(lm('bribery ~ treatment', data = d))
summary(lm('embezzlement ~ treatment', data = d))

summary(lm('bribery ~ treatment + literacy + budget', data = d))

summary(lm('embezzlement ~ treatment + literacy + budget', data = d))

#``Colliders'': What happens if we condition on the other DV?
summary(lm('embezzlement ~ treatment + bribery', data = d)) #still fine
summary(lm('bribery ~ treatment + embezzlement', data = d)) #still fine




