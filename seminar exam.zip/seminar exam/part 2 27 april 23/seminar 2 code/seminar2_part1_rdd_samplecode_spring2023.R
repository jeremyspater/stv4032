rm(list=ls())

A=readRDS('weber input.RDS')

#sequence of distance breakpoints
br=seq(from=min(A$Dist),to=max(A$Dist),by=0.5)
midpoints=(br[-1]+br[-length(br)])/2
A$bin=cut(A$Dist,breaks=br)

B=data.frame(cbind(midpoints,by(A$PctCath,A$bin,mean)))
names(B)=c('midpoints','PctCath')

library(ggplot2)
ggplot(B[which(B$midpoints < 10 & B$midpoints > -10),],
       aes(x=midpoints,y=PctCath))+geom_point(size=2)+
  scale_x_continuous(limits = c(-10, 10))+
  scale_y_continuous(limits = c(-0.25, 1.2))+
  ggtitle("Average Proportion Catholic by Bin") +
  labs(x="Distance (bin midpoint) [km]",y="Avg. Proportion Catholic") +
  theme_bw()

############################################
#RDD regression

rm(list=ls())
A = readRDS('/Users/jeremyspater/Dropbox/duke/oslo/teaching/4032 spring 2023/seminar exam/part 2 27 april 23/seminar 2 code/weber input.RDS')

#restrict sample to towns with fewer than 50% german-speakers
A = A[which(A$PctGerman < 0.5),]

#new data frame consisting of towns with fewer than 1000 residents
A1000 = A[which(A$Pop.1860 < 1000),] #

library(rdrobust)
main0_1000 = rdrobust(A1000$Growth, A1000$Dist)

summary(main0_1000)

############################################