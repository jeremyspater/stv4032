#based on /Users/jeremyspater/Dropbox/duke/oslo/teaching/stv4020b/4020b seminar assignments/seminar 2 25 november/RDD/rdd exam/v2 DATA GENERATING and analysis exam_part2.R

library(ggplot2)

rm(list=ls())

set.seed(2666)

#generate officer data
b = rnorm(789, mean = 1000, sd = 500)
b[which(b<0)] = -b[which(b<0)] #make negative budgets positive

hist(b)

audit = b >= 1000

summary(audit)

violence = rnorm(length(b), mean = 50 + b/1000*20 - 20*audit, sd = 18)

hist(violence)
#put them between 0 and 100
#those outside [0,100] get replaced with random draws from runif[0,100]
violence[which(violence < 0 | violence > 100)] = runif(length(violence[which(violence < 0 | violence > 100)]),
                                                 min = 0, max = 100)
summary(violence)
hist(violence)

plot(b, violence)

df = data.frame(o = b, violence = violence, supervision = as.numeric(audit))

#saveRDS(df, file = '4032_2023_exam_part_2_RDD.RDS')
df = readRDS('/Users/jeremyspater/Dropbox/duke/oslo/teaching/4032 spring 2023/seminar exam/part 2 27 april 23/exam 2 code/4032_2023_exam_part_2_RDD.RDS')

ggplot(data = df, aes(x = o, y = supervision)) + geom_point() 

ggplot(data = df, aes(x = o, y = violence)) + geom_point()

#make bins
br = seq(from = 0, to = max(df$o), by = 50)
midpoints=(br[-1]+br[-length(br)])/2
df$bin=cut(df$o, breaks=br)

df2 = data.frame(cbind(midpoints, by(df$violence, df$bin, mean)))
names(df2)=c('midpoints','violence')
ggplot(data = df2) + geom_point(aes(x = midpoints, y = violence))

library(rdrobust)
df$o2 = df$o - 100
#model0 = rdrobust(df$violence, df$b2)# - 1E9)
#summary(model0)
model1 = rdrobust(df$violence, df$o2)
#model2 = rdrobust(df$violence, df$b)
summary(model1)

