library(tidyverse)
rm(list=ls())

d = data.frame(Y1 = c(1, 1, 1, 5, 5, 6, 7, 7, 8, 9, 10), 
               Y0 = c(10, 5,4,6,1,7,8,10,2,6,6), 
               Age = c(29, 35, 19, 45, 65, 50, 77, 18, 85, 96, 77))















d$TE = d$Y1 - d$Y0
d$D = (d$TE > 0) %>% as.numeric()
d$Y = d$Y1*d$D + d$Y0*(!d$D)



d


#d$TE
#d$Y == pmax(d$Y1, d$Y0) #check

#spoilers below



#"logical indexing" is used in the following three lines
#eg "d[d$D == 1,'Y']" selects the rows where D is 1 
SDO = mean(d[d$D == 1,'Y']) - mean(d[d$D == 0, 'Y'])
ATT = mean(d[d$D == 1, 'TE'])
ATU = mean(d[d$D == 0, 'TE'])
ATE = mean(d$TE)








#Selction bias: E[Y0|D=1] - E[Y0|D=0]
SB = mean(d[d$D == 1,'Y0']) - mean(d[d$D == 0,'Y0'])
#Heterogeneous treatment effects bias:
pi = mean(d$D)
HTE = (1-pi) * (ATT - ATU)

ATE + SB + HTE #should be same value as SDO
