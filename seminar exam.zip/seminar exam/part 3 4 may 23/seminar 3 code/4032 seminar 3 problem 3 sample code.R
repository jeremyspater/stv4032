rm(list=ls())
library(ggplot2)

set.seed(666)
#dgp
DemandShock = rnorm(1000, 0, 2)

Debt = abs(60 + 10*DemandShock + rnorm(1000, 0, 10))

Growth = 3 - DemandShock + rnorm(1000, 0, 2.5)

df = data.frame(DemandShock, Debt, Growth)

#part 1
#make plot

#part 2
lm1 = lm('Growth ~ Debt + DemandShock', data = df)
summary(lm1)
resid1 = lm1$residuals

#part 3
lm2 = lm('Growth ~ Debt', data = df)
summary(lm2)
resid2 = lm2$residuals

#part 4
cor(df$Debt, resid2)

eta = resid1 + lm1$coefficients['DemandShock']*df$DemandShock

#correlationn btw debt and eta

#mean eta for debt below 50
#mean eta for debt >= 50
 
