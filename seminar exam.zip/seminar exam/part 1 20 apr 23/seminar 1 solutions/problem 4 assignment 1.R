rm(list=ls())

library(tidyverse)
library(stargazer)

#This part is Cunningham's code, identical to version on website version of book

tb <- tibble(
  female = ifelse(runif(10000)>=0.5,1,0),
  ability = rnorm(10000),
  discrimination = female,
  occupation = 1 + 2*ability + 0*female - 2*discrimination + rnorm(10000),
  wage = 1 - 1*discrimination + 1*occupation + 2*ability + rnorm(10000) 
)

lm_1 <- lm(wage ~ female, tb)
lm_2 <- lm(wage ~ female + occupation, tb)
lm_3 <- lm(wage ~ female + occupation + ability, tb)

stargazer(lm_1,lm_2,lm_3, type = "text", 
          column.labels = c("Biased Unconditional", 
                            "Biased",
                            "Unbiased Conditional"))

##############

#JS modified version 2 Nov 2021: say that discrimination affects education

rm(list=ls())
set.seed(1234) #this line is to make the results identical every time (because we are generating random numbers below)
#if we didn't set the seed, we would get *slightly* different results every time
#setting the seed to a different value would also give *slightly* different results. try it if you want

tb <- tibble(
  female = ifelse(runif(10000)>=0.5,1,0),
  ability = rnorm(10000),
  discrimination = female,
  education = 1 + 2*ability - 2*discrimination + rnorm(10000),
  occupation = 1 + 2*ability + 2*education + rnorm(10000),
  wage = 1 - 1*discrimination + 1*occupation + education + 
    2*ability + rnorm(10000)
)

lm_1 <- lm(wage ~ female, tb)
lm_2 <- lm(wage ~ female + occupation, tb)
lm_3 <- lm(wage ~ female + occupation + ability, tb)


summary(lm_1)
summary(lm_2)
summary(lm_3)





#######








lm_4 <- lm(wage ~ female + occupation + education + ability, tb)
summary(lm_4)


lm_5 <- lm(wage ~ female + occupation + education, tb)
summary(lm_5)
