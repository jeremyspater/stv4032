#based on /Users/jeremyspater/Dropbox/duke/oslo/teaching/stv4020b/4020b seminar assignments/seminar 1 18 november/exam questions part 1 code/JS code Q1E1 waterways problem simulate data.R
#change dgp and generate new dataset
#21 april 2023

library(tidyverse)
#library(Rlab) 

set.seed(666)

#data generating process:
#DV is corruption, say 2 types, embezzlement and bribery
#Covariates are literacy and budget
##Embezzlement is more sensitive to budget; bribery to literacy
#Treatment is NGO monitoring
##community monitoring is more effective against embezzlement
#There are 379 municipalities in the country, of which 
#189 are assigned to the treatment and 190 are assigned to the control group

d = data.frame(#treatment = rbern(n=1000, prob = 0.5),
               budget = rnorm(n = 379, mean = 1000, sd = 100),
               #flow_rate = rnorm(n = 379, mean = 75, sd = 25)
               literacy = runif(n = 379, min = 50, max = 100)
)

#industry = c(rnorm(n = 900, mean = 10, sd = 3), rnorm(n = 100, mean = 80, sd = 5))  #percent of zoning in local area

summary(d$budget)               
hist(d$literacy)

#d$treatment = sample(temp) #create randomly assigned treatment variable, ensuring 500 1's and 500 0's
#rm(temp)
#summary(d$treatment)
temp = c(rep(0,190), rep(1,189))
d$treatment = sample(temp, replace = FALSE, size = nrow(d))
rm(temp)

summary(lm('treatment ~ literacy + budget', data = d)) #check that treatment is uncorrelated with covariates


#library(fmsb)
library(scales)
#create embezzlement DV: strongly affected by treatment and budget, less by literacy
temp = rnorm(n = nrow(d), mean = 0.42*scale(d$budget) + 
                      -0.162*scale(d$literacy) +
                      -0.63*d$treatment, sd = 1.5)*36  + 420  #arbitrary scaling factor
d$embezzlement = rescale(temp, c(0,100)) #put on 0 to 100 scale
rm(temp)
summary(d$embezzlement)
hist(d$embezzlement)

#create chemicals DV: strongly affected by industry, flow rate; less strongly by income, treatment
# d$chemicals = rnorm(n = 1000, mean = 0.278*scale(d$industry) + 
#                       -0.162*scale(d$flow_rate) - 0.103*scale(d$local_income) +
#                       -0.29*d$treatment, sd = 1.5)*63.2  + 420 #arbitrary scaling factor
# 
# summary(d$chemicals)
# hist(d$chemicals)

# #Create Trash DV: heavily affected by local income and treatment
# d$trash = rnorm(n = 1000, mean = 0.072*scale(d$industry) + 
#                   -0.055*scale(d$flow_rate) - 0.334*scale(d$local_income) +
#                   -0.57*d$treatment, sd = 1.5)*13.4  + 100 #arbitrary scaling factor

#create bribery dv: strongly affected by literacy, less by treatment and budget
temp = rnorm(n = nrow(d), mean = 0.18*scale(d$budget) + 
               -0.48*scale(d$literacy) +
               -0.32*d$treatment, sd = 1.8)*39  + 333  #arbitrary scaling factor
d$bribery = rescale(temp, c(0,100)) #put on 0 to 100 scale
rm(temp)
summary(d$bribery)
hist(d$bribery)
cor(d$bribery, d$embezzlement) #surprisingly pretty low even though correlated with the same stuff . . .

summary(lm('embezzlement ~ treatment', data = d)) #- ***
summary(lm('bribery ~ treatment', data = d)) #- *


#write csv
write_csv(d, file = '4032_2023_week1_Q3_Corruption.csv')

# #create scaled versions of variables
# d$industry_s = scale(d$industry)
# d$flow_rate_s = scale(d$flow_rate)
# d$local_income_s = scale(d$local_income)
# d$chemicals_s = scale(d$chemicals)
# d$trash_s = scale(d$trash)
# 
# summary(lm('chemicals_s ~ treatment + industry + flow_rate + local_income', data = d))
# summary(lm('chemicals_s ~ treatment + industry_s + flow_rate_s + local_income_s', data = d))
# #treatment barely significant. depends on the draw from rnorm above;
# #running the code additional times sometimes delivers different results, with p > 0.05
# 
# 
# summary(lm('trash ~ treatment + industry_s + flow_rate_s + local_income_s', data = d))
# summary(lm('trash_s ~ treatment + industry_s + flow_rate_s + local_income_s', data = d))

#4032_2023_week1_Q3_Corruption.csv

