#Replicating Trounstine 2016, "Segregation and Inequality in Public Goods" (AJPS)

rm(list=ls()) #clear workspace
library(AER)  #package for ivreg

#Read input file downloaded from Canvas
#you may need to change your working directory to the path where the file is: setwd()
#or move the file to your working directory: getwd()
#or just copy-paste the input file's full path into the argument, eg:

#NOTE 11 JAN '24
#This file is large (64Mb) and not included in this folder.
#You can find this on the AJPS replication archive 
B = readRDS('fin_seg.rds')
#################################################################################

#################################################################################

#Subset the data to only those observations with nonzero values of the dependent variable
B1 = B[which(B$dgepercap_cpi != 0),] 

IV = ivreg(
  formula = dgepercap_cpi ~
    H_citytract_NHW_i + #endogenous regressor
    dgepercap_cpilag + diversityinterp + pctblkpopinterp + #covariates part 1
    pctasianpopinterp + pctlatinopopinterp + #covariates 2
    medincinterp + pctlocalgovworker_100 + pctrentersinterp + #covariates 3
    pctover65 + pctcollegegradinterp + #covariates 4
    northeast + south + midwest + y5 + y9 |#last covariates
    . - H_citytract_NHW_i + #everything from before, but drop the endogenous variable
    total_rivs_all + logpop,#plus instruments
  data = B1) #

summary(IV)

#Now, we can try the simplest possible IV regression
IV2 = ivreg(
  formula = dgepercap_cpi ~
    H_citytract_NHW_i | #endogenous regressor
    total_rivs_all,# instrument
  data = B1)

summary(IV2)

