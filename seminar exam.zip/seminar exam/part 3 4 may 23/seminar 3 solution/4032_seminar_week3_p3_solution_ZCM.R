rm(list=ls())
library(ggplot2)

set.seed(666)
#dgp
DemandShock = rnorm(1000, 0, 2)

Debt = abs(60 + 10*DemandShock + rnorm(1000, 0, 10))

Growth = 3 - DemandShock + rnorm(1000, 0, 2.5)

df = data.frame(DemandShock, Debt, Growth)

#part 1
ggplot(data = df) + geom_point(aes(x = Debt, y = Growth))

#part 2
lm1 = lm('Growth ~ Debt + DemandShock', data = df)
summary(lm1)
resid1 = lm1$residuals

#part 3
lm2 = lm('Growth ~ Debt', data = df)
summary(lm2)
resid2 = lm2$residuals

#part 4
cor(df$Debt, resid2)

eta = resid1 + lm1$coefficients['DemandShock']*df$DemandShock

cor(df$Debt, eta)

mean(eta[df$Debt < 50]) 
mean(eta[df$Debt >= 50]) 
