rm(list=ls())

s = function(x){summary(factor(x))}


df = readRDS('STV4032Week3ExamP2Input.RDS')

df$Sweden = df$Country == 'Sweden'

#now do a classic 2x2 DiD with two-way fixed effects
df2 = df[df$Time >= 0,]

DiD = lm(
  'GHG ~ Country + Time + Country*Time',
  data = df2
)

summary(DiD)

#Now let's test parallel trends.
df3 = df[df$Time < 1,]

ParTr = lm(
  'GHG ~ Country + Time + Country*Time',
  data = df3
)

summary(ParTr)
