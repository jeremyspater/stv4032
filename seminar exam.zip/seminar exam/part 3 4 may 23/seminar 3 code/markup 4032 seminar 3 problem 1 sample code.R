#adapted from https://www.econometrics-with-r.org/10-rwpd.html

library(AER)
library(plm)
library(stargazer)

data(Fatalities)

dim(Fatalities)

#rate of fatalities per 10k people
Fatalities$fatal_rate <- Fatalities$fatal / Fatalities$pop * 10000

#subset by year
Fatalities1982 <- subset(Fatalities, year == "1982")
Fatalities1988 <- subset(Fatalities, year == "1988")

#linear models, separating by year
fatal1982_mod <- lm(fatal_rate ~ beertax, data = Fatalities1982)
fatal1988_mod <- lm(fatal_rate ~ beertax, data = Fatalities1988)

#plot 1982
plot(x = Fatalities1982$beertax, 
     y = Fatalities1982$fatal_rate, 
     xlab = "Beer tax (in 1988 dollars)",
     ylab = "Fatality rate (fatalities per 10000)",
     main = "Traffic Fatality Rates and Beer Taxes in 1982",
     ylim = c(0, 4.5),
     pch = 20, 
     col = "steelblue")

#line of best fit for 1982, from model above
abline(fatal1982_mod, lwd = 1.5)

#plot 1988
plot(x = Fatalities1988$beertax, 
     y = Fatalities1988$fatal_rate, 
     xlab = "Beer tax (in 1988 dollars)",
     ylab = "Fatality rate (fatalities per 10000)",
     main = "Traffic Fatality Rates and Beer Taxes in 1988",
     ylim = c(0, 4.5),
     pch = 20, 
     col = "steelblue")

#line of best fit for 1988, from model above
abline(fatal1988_mod, lwd = 1.5)

#first differences
diff_fatal_rate <- Fatalities1988$fatal_rate - Fatalities1982$fatal_rate
diff_beertax <- Fatalities1988$beertax - Fatalities1982$beertax
fatal_diff_mod <- lm(diff_fatal_rate ~ diff_beertax)

# plot the differenced data
plot(x = diff_beertax, 
     y = diff_fatal_rate, 
     xlab = "Change in beer tax (in 1988 dollars)",
     ylab = "Change in fatality rate (fatalities per 10000)",
     main = "Changes in Traffic Fatality Rates and Beer Taxes in 1982-1988",
     xlim = c(-0.6, 0.6),
     ylim = c(-1.5, 1),
     pch = 20, 
     col = "steelblue")

# add the regression line to plot
abline(fatal_diff_mod, lwd = 1.5)

#fixed effects regression (ignoring heteroskedasticity)
fatal_fe_lm_mod <- lm(fatal_rate ~ beertax + state - 1, data = Fatalities) # - 1: exclude the intercept
summary(fatal_fe_lm_mod)

summary(lm(fatal_rate ~ beertax + state, data = Fatalities)) #this time including the intercept

#fixed effects regression, accounting for heteroskedasticity
fatal_fe_mod <- plm(fatal_rate ~ beertax, 
                    data = Fatalities,
                    index = c("state", "year"), 
                    model = "within")
coeftest(fatal_fe_mod, vcov. = vcovHC, type = "HC1")

# plot_model(fatal_fe_mod, type = "pred", terms = "beertax")

# plot(x = Fatalities$beertax, 
#      y = Fatalities$fatal_rate, 
#      xlab = "Beer tax (in 1988 dollars)",
#      ylab = "Fatality rate (fatalities per 10000)",
#      main = "Traffic Fatality Rates and Beer Taxes in 1988",
#      ylim = c(0, 4.5),
#      pch = 20, 
#      col = "steelblue")

#plot(x = c(0,10), y = c(0,10))
#abline(1, 1)

#test = predict(fatal_fe_mod)

predicted_oh = fatal_fe_lm_mod$coefficients['stateoh'] + 
  fatal_fe_lm_mod$coefficients['beertax'] * Fatalities$beertax

predicted_ca = fatal_fe_lm_mod$coefficients['stateca'] + 
  fatal_fe_lm_mod$coefficients['beertax'] * Fatalities$beertax

predicted_vt = fatal_fe_lm_mod$coefficients['statevt'] + 
  fatal_fe_lm_mod$coefficients['beertax'] * Fatalities$beertax


ggplot() + geom_line(aes(x = Fatalities$beertax,
                         y = predicted_oh, color = 'ohio')) +
  geom_line(aes(x = Fatalities$beertax,
                y = predicted_vt, color = 'vermont')) +
  scale_colour_manual("",
                      breaks = c("ohio", "vermont"),
                      values = c("red", "blue")) +
  xlab('Beer tax') + ylab('Predicted fatalities')


# ggplot() + geom_line(aes(x = Fatalities$beertax,
#                          y = predicted_oh), color = 'red') + 
#   geom_line(aes(x = Fatalities$beertax,
#                 y = predicted_vt), color = 'blue')
