rm(list=ls())

#part 1
df = read.table("public.dat") 
nrow(df)

# Using the codebook, you can figure out the substantive meanings 
# of the variables in the data set. Below, I've just copy-pasted
# the first 34 lines of the codebook, and enumerated them.
# The 4th variable is State, the 12th is full-time employees
# in the first wave, etc.

# 1SHEET           1        3     3.0   sheet number (unique store id)
# 2CHAIN           5        5     1.0   chain 1=bk; 2=kfc; 3=roys; 4=wendys
# 3CO_OWNED        7        7     1.0   1 if company owned
# 4STATE           9        9     1.0   1 if NJ; 0 if Pa                      
# 
# Dummies for location:
# 5SOUTHJ         11       11     1.0   1 if in southern NJ
# 6CENTRALJ       13       13     1.0   1 if in central NJ
# 7NORTHJ         15       15     1.0   1 if in northern NJ
# 8PA1            17       17     1.0   1 if in PA, northeast suburbs of Phila
# 9PA2            19       19     1.0   1 if in PA, Easton etc
# 10SHORE          21       21     1.0   1 if on NJ shore
# 
# First Interview
# 11NCALLS         23       24     2.0   number of call-backs*
# 12EMPFT          26       30     5.2   # full-time employees
# 13EMPPT          32       36     5.2   # part-time employees
# 14NMGRS          38       42     5.2   # managers/ass't managers
# 15WAGE_ST        44       48     5.2   starting wage ($/hr)
# 16INCTIME        50       54     5.1   months to usual first raise
# 17FIRSTINC       56       60     5.2   usual amount of first raise ($/hr)
# 18BONUS          62       62     1.0   1 if cash bounty for new workers
# 19PCTAFF         64       68     5.1   % employees affected by new minimum
# 20MEALS          70       70     1.0   free/reduced price code (See below)
# 21OPEN           72       76     5.2   hour of opening
# 22HRSOPEN        78       82     5.2   number hrs open per day
# 23PSODA          84       88     5.2   price of medium soda, including tax
# 24PFRY           90       94     5.2   price of small fries, including tax
# 25PENTREE        96      100     5.2   price of entree, including tax
# 26NREGS         102      103     2.0   number of cash registers in store
# 27NREGS11       105      106     2.0   number of registers open at 11:00 am
# 
# Second Interview
# 28TYPE2         108      108     1.0   type 2nd interview 1=phone; 2=personal
# 29STATUS2       110      110     1.0   status of second interview: see below
# 30DATE2         112      117     6.0   date of second interview MMDDYY format
# 31NCALLS2       119      120     2.0   number of call-backs*
# 32EMPFT2        122      126     5.2   # full-time employees
# 33EMPPT2        128      132     5.2   # part-time employees
# 34NMGRS2        134      138     5.2   # managers/ass't managers

df$FT1 = as.numeric(df$V12)
df$PT1 = as.numeric(df$V13)
df$Managers1 = as.numeric(df$V14) 

#KC p 775:
#Full- time-equivalent [FTE] employment was cal- culated as the number of full-time workers 
#[including managers] plus 0.5 times the number of part-time workers.
df$FTE1 = df$FT1 + df$Managers1 + 0.5*df$PT1

summary(df$FTE1[which(df$V4 == 0)]) #23.33 
summary(df$FTE1[which(df$V4 == 1)]) #20.44 

#now repeat for wave 2
# 32EMPFT2        122      126     5.2   # full-time employees
# 33EMPPT2        128      132     5.2   # part-time employees
# 34NMGRS2        134      138     5.2   # managers/ass't managers

df$FT2 = as.numeric(df$V32)
df$PT2 = as.numeric(df$V33)
df$Managers2 = as.numeric(df$V34) 

df$FTE2 = df$FT2 + df$Managers2 + 0.5*df$PT2

summary(df$FTE2[which(df$V4 == 0)]) #
summary(df$FTE2[which(df$V4 == 1)]) #

#create new data frame, full length
df2 = data.frame(
  FTE = c(df$FTE1, df$FTE2),
  State = c(df$V4, df$V4),
  Time = c(rep(0,nrow(df)), rep(1,nrow(df)))
  )

summary(lm('FTE ~ State + Time + State*Time' , data = df2))  

